功能模块四:显示指定商品详细信息

完成此功能需要程序
1:data/06_product_detail.php
2:product_list.html
3:js/product_list.js
中间人:发送ajax请求php获取数据->显示html

