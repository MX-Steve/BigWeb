功能模块六:商品添加
完成此功能需要程序
1:data/10_product_add.php   接收参数[商品信息]并且保存数据库
lid        自增长
family_id
title
subtitle
price
promise
spec
lname
os
memory
resolution
video_card
cpu
video_memor
category
disk
details
shelf_time     now()
sold_count     0
is_onsale      0
expire         '0'

2:product_add.html          创建添加商品表单
3:js/product_add.js         中间人

